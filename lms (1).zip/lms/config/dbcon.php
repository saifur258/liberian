<?php

$conn = mysqli_connect("localhost","onlinep2_lms098258","lms#098258","onlinep2_lms");
mysqli_query($conn,'SET CHARACTER SET utf8');
mysqli_query($conn,"SET SESSION collation_connection ='utf8_general_ci'");

?>