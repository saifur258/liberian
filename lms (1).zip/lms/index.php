<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>LMS</title>
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">
</head>
<body>

<br>
<br>
<div class="container">
    <div class="row" >
            <div class="col-sm-4 col-sm-offset-4">
            <a href="librarian/login.php" style="text-transform:Uppercase" class="btn btn-info btn-block  ">Laiberian</a>
            <a href="student/index.php" style="text-transform:Uppercase" class="btn btn-info btn-block">student</a>
            </div>
    </div>
    </div>
</body>
</html>