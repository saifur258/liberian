-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 30, 2015 at 08:44 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_backup`
--
CREATE DATABASE IF NOT EXISTS `db_backup` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `db_backup`;

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`employeeid`, `firstname`, `middlename`, `lastname`) VALUES
(1, 'Carmen', 'N.', 'Natividad'),
(2, 'Jenny', 'P.', 'Lopez');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:20 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (2 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:21 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (2 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:21 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:21 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:21 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:21 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:21 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:22 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:29 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:29 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:29 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:29 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:29 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:29 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:29 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:29 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:29 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:29 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:42 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:42 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:42 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:43 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:43 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:43 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:44 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:44 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:44 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:44 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:45 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:45 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:45 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:45 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:45 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:46 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:46 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:46 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:46 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:46 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:47 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:47 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:47 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:47 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:47 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:47 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:47 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:48 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:48 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:49 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:49 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:49 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:49 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:49 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:51 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:51 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:51 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:51 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:51 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:51 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:51 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:54 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:54 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:54 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 21:57 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 22:02 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 22:02 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 22:02 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

# WordPress : buffernow.com MySQL database backup
#
# Generated: Wednesday 30. December 2015 22:02 UTC
# Hostname: localhost
# Database: `db_backup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `employees`
# --------------------------------------------------------


#
# Delete any existing table `employees`
#

DROP TABLE IF EXISTS `employees`;


#
# Table structure of table `employees`
#

CREATE TABLE `employees` (
  `employeeid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table employees (4 records)
#
 
INSERT INTO `employees` VALUES (1, 'Carmen', 'N.', 'Natividad') ; 
INSERT INTO `employees` VALUES (2, 'Jenny', 'P.', 'Lopez') ; 
INSERT INTO `employees` VALUES (5, 'Janny', 'C.', 'Carpio') ; 
INSERT INTO `employees` VALUES (6, 'Nanny', 'B.', 'Gomez') ;
#
# End of data contents of table employees
# --------------------------------------------------------

