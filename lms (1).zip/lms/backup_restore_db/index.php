<!DOCTYPE html>
<html>
<body>

<?php
    include('conn.php'); 
    require_once('backup_restore.class.php'); 

    $newImport = new backup_restore($host,$db,$user,$pass);

    if(isset($_GET['process'])){
        $process = $_GET['process'];
        if($process == 'backup'){
            $message = $newImport -> backup ();   
        }else if($process == 'restore'){
            $message = $newImport -> restore (); 
            @unlink('backup/database_'.$db.'.sql');
            
        }
    }
    if(isset($_POST['submit'])){        
        $db = 'database_'.$db.'.sql';
        $target_path = 'backup';
        move_uploaded_file($_FILES["file"]["tmp_name"], $target_path . '/' . $db);    
        $message = 'Successfully uploaded. You can now <a href=index.php?process=restore>restore</a> the database!';
    }
?>


<br>
<br>
               <center> <h3>Backup / Restore Database</h3>
           
             
                        <?php if(isset($_GET['process'])): ?>
                            <?php 
                                $msg = $_GET['process'];   
                                $class = 'text-center';
                                switch($msg){
                                    case 'backup':
                                        $msg = 'Backup Successfully!<br />Download the <a href=backup/'.$message.' target=_blank >SQL FILE </a> OR RESTORE IT ANY TIME'; 
                                        break;
                                    case 'restore':
                                        $msg = $message; 
                                        break;
                                    case 'upload':
                                        $msg = $message; 
                                        break;
                                    default:
                                        $class = 'hide';
                                }                                
                            ?>
                                <strong><?php echo $msg; ?></strong><br>
                        <?php endif; ?>
                        
        
                <br>
                            <a href="index.php?process=backup">
                                <button type="button" class="btn btn-success btn-lg span4"><i class="fa fa-database"></i> BACKUP DATABASE</button>
                            </a>
                      
                            <a href="index.php?process=restore">
                                <button type="button" class="btn btn-info btn-lg span4"><i class="fa fa-database"></i> RESTORE DATABASE</button>
                            </a>
                <br />
                <br />
                    <form method="POST" enctype="multipart/form-data" style="border:1px solid #000; width:600px; padding:20px;">
                        <label>Upload SQL File:</label>
                        <input type="file" name="file" class="form-control">
                        <input type="submit" name="submit" class="btn btn-success" value="Upload Database" />
                    </form>
		<center>
		<br>
		<table border="1" cellspacing="0" cellpadding="12">
			<thead>
				<tr>
					<th>First Name</th>
					<th>Middle Initial</th>
					<th>Last Name</th>
				</tr>
			</thead>
			<tbody>
				<?php	
					$result = mysql_query("SELECT * FROM employees")or die(mysql_error());
					while($row = mysql_fetch_array($result)){
				?>
				<tr>
					<td><?php echo $row['firstname']; ?></td>
					<td><?php echo $row['middlename']; ?></td>
					<td><?php echo $row['lastname']; ?></td>
				</tr>
					<?php } ?>
			</tbody>
		</table>
		</center>
  
</center>
<script type="text/javascript">
    <?php if(isset($_POST['add_room'])) echo '$.jGrowl("Added Successfully!");'; ?>
</script>

</body>
</html>