<?php
	$host = 'localhost';
	$user = 'onlinep2_lms098258';
	$pass = 'lms#098258';
	$db = 'onlinep2_lms';
	
?>