<?php
include_once "../config/header.php";

?>
            <!-- CONTENT -->
            <!-- ========================================================= -->
            <div class="content">
                <!-- content HEADER -->
                <!-- ========================================================= -->
                <div class="content-header">
                    <!-- leftside content header -->
                    <div class="leftside-content-header">
                        <ul class="breadcrumbs">
                            <li><i class="fa fa-home" aria-hidden="true"></i><a href="#">Dashboard</a></li>
                            <li><a href="javascript-avoid">Students</a></li>
                        </ul>
                    </div>
                </div>
                <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
                <div class="row animated fadeInDown">
                   

 <!--SEARCHING, ORDENING & PAGING-->
 <div class="row animated fadeInRight">
        
 <div class="col-sm-12">
                    <h4 class="section-subtitle"><b>Students List</b></h4>
                    <div class="panel">
                        <div class="panel-content">
                            <div class="table-responsive">
                                <table id="basic-table" class="data-table table table-striped nowrap table-hover" cellspacing="0" width="100%">
                                    <thead>
                                    <tr>
                                        <th>Student Name</th>
                                        <th>Roll</th>
                                        <th>Reg No</th>
                                        <th>Email</th>
                                        <th>Username</th>
                                        <th>phone</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                   


<?php
include_once "../config/dbcon.php";
$result= mysqli_query($conn, "SELECT * FROM student");
while($row=mysqli_fetch_assoc($result)){



?>

                                    <tr>
                                        <td><?=$row['fname']?></td>
                                        <td><?=$row['roll']?></td>
                                        <td><?=$row['reg']?></td>
                                        <td><?=$row['email']?></td>
                                        <td><?=$row['username']?></td>
                                        <td><?=$row['phone']?></td>
                                        <td><?=$row['status']==1? 'active':'inctive'?></td>
<?php
                                        if($row['status']==1){
                                            ?>
                                            <td><a href="active-status.php?id=<?=base64_encode($row['id'])?>"><i class="btn btn-primary fa fa-arrow-down"></i></a></td>
                                            <?php
                                        }else{
                                            ?>
                                            <td><a href="inactive-status.php?id=<?=base64_encode($row['id'])?>"><i class="btn btn-danger fa fa-arrow-up"></i></a></td>
                                            <?php
                                        }

?>

                                        
                                    </tr>
                                    <?php
                                         }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>







<?php
include_once "../config/footer.php";

?>