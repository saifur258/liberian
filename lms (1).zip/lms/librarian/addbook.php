<?php
include_once "../config/header.php";


?>
            <!-- CONTENT -->
            <!-- ========================================================= -->
            <div class="content">
                <!-- content HEADER -->
                <!-- ========================================================= -->
                <div class="content-header">
                    <!-- leftside content header -->
                    <div class="leftside-content-header">
                        <ul class="breadcrumbs">
                            <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                            <li><a href="addbook.php">Add Book</a></li>
                        </ul>
                    </div>
                </div>
                <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
                <div class="row animated fadeInDown">
                   
<?php
include_once "../config/dbcon.php";
if(isset($_POST['submit'])){
    $book_name=$_POST['book_name'];
    $book_author_name=$_POST['book_author_name'];
    $book_publication_name=$_POST['book_publication_name'];
    $book_purchase_date=$_POST['book_purchase_date'];
    $book_price=$_POST['book_price'];
    $book_qty=$_POST['book_qty'];
    $book_available_qty=$_POST['book_available_qty'];
    $librarian_username=$_SESSION['librarian-login'];

    $image=explode('.' , $_FILES['book_img']['name']);
    $image=end($image);
    $imagename = date('ydmhis.').$image;

 $result=mysqli_query($conn,"INSERT INTO `books`(`book_name`, `book_img`, `book_author_name`, `book_publication_name`, `book_purchase_date`, `book_price`, `book_qty`, `book_available_qty`, `librarian_username`) VALUES ('$book_name','$imagename','$book_author_name','$book_publication_name','$book_purchase_date','$book_price','$book_qty','$book_available_qty','$librarian_username')");
if($result){
move_uploaded_file($_FILES['book_img']['tmp_name'], '../image/books/'.$imagename);
$success="Book Save Successfully";
header('location:book-manage.php');

}else{
$error="Book  not Save Successfully";

}
   

    }
?>
                <div class="col-sm-12 col-md-6 col-md-offset-3">
                   
<!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-success sms=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
<?php
                    if(isset($success)){
                    ?>
                        
                    <div class="alert alert-success" role="alert" >
                    <?= $success?>;
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                    </div>
                    <?php   
                    }
                    ?>
                     <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-End success sms=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
                     <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-danger sms1=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
                    <?php
                    if(isset($error)){
                    ?>
                        
                    <div class="alert alert-danger" role="alert" >
                    <?= $error?>;
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                    </div>
                    <?php   
                    }
                    ?>
                     <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-1 End danger sms=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->



                    <div class="panel">
                        <div class="panel-content">
                            <div class="row">
                                <div class="col-md-12">
                                    <form method="POST" action="addbook.php" class="form-horizontal" enctype="multipart/form-data">
                                        <div class="col-md-12 bg-secondary">
                                            <h5 style="text-align: center; text-transform: uppercase; background: azure; padding: 9px;"  class="mb-lg ">Add Books</h5>
                                       </div>
                                        <div class="form-group">
                                            <label for="bookname" class="col-sm-4 control-label">Book Name</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" name="book_name" placeholder="book_name" require>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="book_img" class="col-sm-4 control-label">Book Photo</label>
                                            <div class="col-sm-8">
                                                <input type="file" class="form-control" name="book_img" placeholder="Book Image" require>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="book_author_name" class="col-sm-4 control-label">Book Author Name</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" name="book_author_name" placeholder="book_author_name" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="book_publication_name" class="col-sm-4 control-label">Book Publication Name</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" name="book_publication_name" placeholder="book_publication_name">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="book_purchase_date" class="col-sm-4 control-label">Book Purchase Date</label>
                                            <div class="col-sm-8">
                                                <input type="date" class="form-control" name="book_purchase_date" placeholder="book_purchase_date">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="book_price" class="col-sm-4 control-label">Book Price</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" name="book_price" placeholder="book_price">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="book_qty" class="col-sm-4 control-label">Book Quantity</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" name="book_qty" placeholder="book_qty">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="book_available_qty" class="col-sm-4 control-label">Book Available </label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" name="book_available_qty" placeholder="book_available_qty">
                                            </div><br/><br/>
                                       
                                        
                                        <div class="form-group">
                                            <div class="col-sm-offset-4 col-sm-8 float:right">
                                                <button type="submit" name="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save Book</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>




<?php
include_once "../config/footer.php";

?>