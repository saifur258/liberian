<?php
include_once "../config/header.php";

?>
            <!-- CONTENT -->
            <!-- ========================================================= -->
            <div class="content">
                <!-- content HEADER -->
                <!-- ========================================================= -->
                <div class="content-header">
                    <!-- leftside content header -->
                    <div class="leftside-content-header">
                        <ul class="breadcrumbs">
                        <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                            <li><a href="book-manage.php">Book manage</a></li>
                        </ul>
                    </div>
                </div>
                <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
                <div class="row animated fadeInDown">
         <!--COLUMNS HIDDEN RESPONSIVE-->
                  <div class="col-lg-12">
                   
                    <div class="panel">
                        <div class="panel-content">
                            <div class="row">  
                             
                                <div  class="muted pull-right">
                                         <a href="admitstu.php"> <Button type="submit" class="btn btn-info" style=" width:200px; height:35px; left:" /><i class="fa fa-plus"></i>&nbsp; ADMIT STUDENT</button></a></div>
                                         <button onclick="printContent('print')"  class="btn btn-info large fa fa-print" style=" width:80px; height:35px; right:100px;">&nbsp;Print</button>
                                </div>
                    <div id="print" >

           <div class="col-sm-12">
                    <h4 class="section-subtitle"><b>Students List</b></h4>
                    <div class="panel">
                        <div class="panel-content">
                            <div class="table-responsive">
                                <table id="basic-table" class="data-table table table-striped nowrap table-hover" cellspacing="0" width="100%">
                                    <thead>
                                    <tr>
                                        <th>book Name</th>
                                        <th>book Image</th>
                                        <th>book_author_name</th>
                                        <th>book_publication_name</th>
                                        <th>book_purchase_date</th>
                                        <th>book_price</th>
                                        <th>book_qty</th>
                                        <th>book_available_qty</th>
                                        
                                       
                                        <th>Action</th>
                                        
                                        
                                        
                                    </tr>
                                    </thead>
                                    <tbody>
                                   


<?php
include_once "../config/dbcon.php";
$result= mysqli_query($conn, "SELECT * FROM books");
while($row=mysqli_fetch_assoc($result)){



?>

                                    <tr>
                                        <td><?=$row['book_name']?></td>
                                        <td><img src="../image/books/<?=$row['book_img']?>" alt="photo" width= 50px height=50px ></td>
                                        <td><?=$row['book_author_name']?></td>
                                        <td><?=$row['book_publication_name']?></td>
                                        <td><?= date('d/M/Y', strtotime($row['book_purchase_date']))?></td>
                                        <td><?=$row['book_price']?></td>
                                        <td><?=$row['book_qty']?></td>
                                        <td><?=$row['book_available_qty']?></td>
                                      
                                        <td><button class="btn btn btn-info" data-toggle="modal" data-target="#book-<?= $row['id'];?>"><i class="fa fa-eye" ></i></button>
                                        <button class="btn btn btn-warning" data-toggle="modal" data-target="#update-<?= $row['id'];?>"><i class="fa fa-pencil" ></i></button>

                                         <a href="delete.php?bookdelete=<?= base64_encode($row['id'])?>" ><button class="btn btn btn-danger" onclick="return confirm('are you sure?')"><i class="fa fa-trash"></i></button></a></td>
                                    </tr>
                                    <?php
                                         }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
               
                         
                         
  <!--INFO modal-->
           <?php
include_once "../config/dbcon.php";
$result= mysqli_query($conn, "SELECT * FROM books");
while($row=mysqli_fetch_assoc($result)){



?>
                 
                            <!-- Modal -->
                            <div class="modal fade" id="book-<?= $row['id']?>" tabindex="-1" role="dialog" aria-labelledby="modal-info-label">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header state modal-info">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                            <h4 class="modal-title" id="modal-info-label"><i class="fa fa-book"></i>Book Details</h4>
                                        </div>
                                        <div class="modal-body">
                                        <table class="table table-borderd text-uppercase">
                                            <tr>
                                               <th>book Name</th>
                                                 <td><?=$row['book_name']?></td>
                                            </tr>
                                            <tr>
                                                <th>book Image</th>
                                               <td><img src="../image/books/<?=$row['book_img']?>" alt="photo" width= 50px height=50px ></td>
                                            </tr>
                                            <tr>
                                                
                                                 <th>book_author_name</th>
                                            <td><?=$row['book_publication_name']?></td>
                                       
                                            </tr>
                                            <tr>
                                                
                                                <th>book_publication_name</th>
                                               
                                                <td><?=$row['book_publication_name']?></td>
                                       
                                            </tr>
                                            <tr>
                                                
                                                 <th>book_purchase_date</th>
                                              
                                        <td><?= date('d/M/Y', strtotime($row['book_purchase_date']))?></td>
                                              
                                      
                                       
                                            </tr>
                                            <tr>
                                                
                                                <th>book_price</th>
                                        <td><?=$row['book_price']?></td>
                                            </tr> 
                                            <tr>
                                                
                                                <th>book_qty</th>
                                             
                                        <td><?=$row['book_qty']?></td>
                                            </tr>
                                            <tr>
                                                
                                                <th>book_available_qty</th>
                                               
                                                 <td><?=$row['book_available_qty']?></td>
                                               
                                                 <td></td>
                                            </tr>
                                        </table>



                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>                        
                          <?php
                                         }
                                    ?>
                                    
                                    
                                    
                            
  <!-------------------------------------------primary update modal------------------------------------------------------------------------------------------>
           <?php
include "../config/dbcon.php";
$result= mysqli_query($conn, "SELECT * FROM books");
while ($row = mysqli_fetch_assoc($result)){



?>
                 
                            <!-- Modal -->
                            <div class="modal fade" id="update-<?= $row['id'];?>" tabindex="-1" role="dialog" aria-labelledby="modal-info-label">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header state modal-info">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                            <h4 class="modal-title" id="modal-info-label"><i class="fa fa-pencil"></i>Update Book </h4>
                                        </div>
                                            <div class="panel">
                                                <div class="panel-content">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <form method="POST" action="">
                                        
                                        <div class="form-group">
                                            <label for="bookname" class="col-sm-4 control-label">Book Name</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" name="book_name" value="<?=$row['book_name'];?>" placeholder="book_name" require>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="book_img" class="col-sm-4 control-label">Book Photo</label>
                                            <div class="col-sm-8">
                                                <input type="file" class="form-control" name="book_img" placeholder="Book Image" require>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="book_author_name" class="col-sm-4 control-label">Book Author Name</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" name="book_author_name" value="<?=$row['book_author_name'];?>"  placeholder="book_author_name" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="book_publication_name" class="col-sm-4 control-label">Book Publication Name</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" name="book_publication_name" placeholder="book_publication_name">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="book_purchase_date" class="col-sm-4 control-label">Book Purchase Date</label>
                                            <div class="col-sm-8">
                                                <input type="date" class="form-control" name="book_purchase_date" placeholder="book_purchase_date">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="book_price" class="col-sm-4 control-label">Book Price</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" name="book_price" placeholder="book_price">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="book_qty" class="col-sm-4 control-label">Book Quantity</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" name="book_qty" placeholder="book_qty">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="book_available_qty" class="col-sm-4 control-label">Book Available </label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" name="book_available_qty" placeholder="book_available_qty">
                                            </div>
                                                                <div class="form-group">
                                            <div class="col-sm-offset-4 col-sm-8 float:right">
                                                <button type="submit" name="submit" class="btn btn-primary btn-block"><i class="fa fa-save"></i> Book Update</button>
                                            </div>
                                                           
                                                           
                                                           
                                                           
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                    </div>
                                </div>
                            </div>                        
                          <?php
                          }
                        ?>                               
                                    
                       
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
<?php
include_once "../config/footer.php";

?>