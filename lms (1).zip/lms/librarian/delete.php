<?php

require_once "../config/dbcon.php";

if(isset($_GET['bookdelete'])){
  $id=base64_decode( $_GET['bookdelete']);
  mysqli_query($conn, "DELETE FROM `books` WHERE id = $id");
  
  header('location:book-manage.php');
}


?>