<?php
include_once "../config/dbcon.php";
$id =base64_decode($_GET['id']);
$result = mysqli_query($conn,"UPDATE `student` SET `status`=0 WHERE `id`=$id");
header('location:students.php');

?>