<?php
include_once "../config/dbcon.php";
session_start();
if(isset($_SESSION['student-login'])){
    header('location: index.php');
}



if(isset($_POST['student-register'])){
 $fname=$_POST['fname'];
 $lname=$_POST['lname'];
 $roll=$_POST['roll'];
 $reg=$_POST['reg'];
 $phone=$_POST['phone'];
 $email=$_POST['email'];
 $username=$_POST['username'];
 $password=$_POST['password'];
 $password_hash= password_hash($password, PASSWORD_DEFAULT);

$input_errores=array();

 if(empty($fname)){

    $input_errores["fname"]="Firstname field is required!";


 }
 if(empty($lname)){

    $input_errores["lname"]="Lastname field is required!";


 }
 if(empty($email)){

    $input_errores["email"]="email field is required!";

 }
 if(empty($roll)){

    $input_errores["roll"]="roll field is required!";


 }
 if(empty($phone)){

    $input_errores["phone"]="phone field is required!";


 }

 if(empty($reg)){

    $input_errores["reg"]="reg field is required!";


 }


 if(empty($username)){

    $input_errores["username"]="username field is required!";


 }
 if(empty($password)){

    $input_errores["password"]="password field is required!";
   
    
 }


$errorescount=count($input_errores);
if($errorescount==0){
//Usernamecheck
    $query = "SELECT * FROM student WHERE username='$username' LIMIT 1";

if (mysqli_num_rows(mysqli_query($conn,$query)) == 0){

                //emailcheck
            $query = "SELECT * FROM student WHERE email='$email' LIMIT 1";

            if (mysqli_num_rows(mysqli_query($conn,$query)) == 0){
                                //username character Test
                            if(strlen($username)>5){
                                //password character Test
                                if(strlen($password)>3){
                                
                                 //Data Insert 

                                    $query= mysqli_query($conn, "INSERT INTO `student`(`fname`, `lname`, `roll`, `reg`, `email`, `username`, `password`,`status`, `phone`) VALUES ('$fname','$lname','$roll','$reg','$email','$username','$password_hash','0','$phone')");
                                    if($query){
                                        $success = "Your Registration Successfull";
                                    }else{

                                        $error = "Your Registration Not success";
                                    }


                                     //Data Insert End
                                
                                }else{
                                    $usernamecheck= "password is more than 3 character.<br/>";
                                }
                                    //password character Test End
                            }else{
                                $usernamecheck= "Username is more than 5 character.<br/>";
                            }
                            

                                //username character Test End

            }else{
                $usernamecheck= "email is already in use.<br/>";

                    }

            //emailcheck end

}else{

 $usernamecheck= "Username is already in use.<br/>";

  }  

//Usernamecheck End




}
}

?>






<!doctype html>
<html lang="en" class="fixed accounts sign-in">


<!-- Mirrored from myiideveloper.com/helsinki/last-version/helsinki_green-dark/src/pages_register.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Mar 2019 13:06:17 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    
    <link rel="apple-touch-icon" sizes="120x120" href="../assets/favicon/apple-icon-120x120.png">
    <link rel="icon" type="image/png" sizes="192x192" href="../assets/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../assets/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/favicon/favicon-16x16.png">
    <title>LMS</title>
    <!--BASIC css-->
    <!-- ========================================================= -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../assets/vendor/font-awesome/css/font-awesome.css">
    <link rel="stylesheet" href="../assets/vendor/animate.css/animate.css">
    <!--SECTION css-->
    <!-- ========================================================= -->
    <!--TEMPLATE css-->
    <!-- ========================================================= -->
    <link rel="stylesheet" href="../assets/stylesheets/css/style.css">
    <link rel="stylesheet" href="../assets/stylesheets/css/mystyle.css">
</head>

<body>
<div class="wrap">




    <!-- page BODY -->
    <!-- ========================================================= -->
    <div class="page-body animated slideInDown">
        <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
        <!--LOGO-->
        <div class="logo">
            <h1 class="text-center">REGISTER FORM</h1>
            <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-success sms=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
                    <?php
                    if(isset($success)){
                    ?>
                        
                    <div class="alert alert-success" role="alert" >
                    <?= $success?>;
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                    </div>
                    <?php   
                    }
                    ?>
                     <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-End success sms=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
                     <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-danger sms1=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
                    <?php
                    if(isset($error)){
                    ?>
                        
                    <div class="alert alert-danger" role="alert" >
                    <?= $error?>;
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                    </div>
                    <?php   
                    }
                    ?>
                     <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-1 End danger sms=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
                     <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-2 danger sms=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
                     <?php
                    if(isset($usernamecheck)){
                    ?>
                        
                    <div class="alert alert-danger" role="alert" >
                    <?= $usernamecheck?>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                    </div>
                    <?php   
                    }
                    ?>
                     <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-End2 danger sms=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->


        </div>
        <div class="box">
            <!--SIGN IN FORM-->
            <div class="panel mb-none">
                <div class="panel-content bg-scale-0">




                    <form method="POST"  action="">
                        <div class="form-group mt-md">
                            <span class="input-with-icon">
                                <input type="text" class="form-control" name="fname" placeholder="First-name" value="<?= isset($fname)? $fname:'' ?>">
                                <i class="fa fa-user"></i>
                             
                            </span>

                            <?php
                                if(isset($input_errores["fname"])){
                                 echo  '<span class="inputsms">'.  $input_errores['fname']  . '</span>';
                                }
                                ?>


                        </div>
                        <div class="form-group mt-md">
                            <span class="input-with-icon">
                                <input type="text" class="form-control" name="lname" placeholder="Last-Name"  value=<?= isset($lname)? $lname:'' ?>>
                                <i class="fa fa-user"></i>
                            </span>
                            <?php
                                if(isset($input_errores["lname"])){
                                 echo  '<span class="inputsms">'.  $input_errores['lname']  . '</span>';
                                }
                                ?>



                        </div>
                        <div class="form-group mt-md">
                            <span class="input-with-icon">
                                <input type="text" class="form-control" name="roll" placeholder="Roll" pattern=[0-9]{6} value="<?= isset($roll)? $roll:'' ?>">
                                <i class="fa fa-user"></i>
                            </span>
                            <?php
                                if(isset($input_errores["roll"])){
                                 echo  '<span class="inputsms">'.  $input_errores['roll']  . '</span>';
                                }
                                ?>


                        </div>
                        <div class="form-group mt-md">
                            <span class="input-with-icon">
                                <input type="text" class="form-control" name="reg" placeholder="Reg No" pattern=[0-9]{6} value="<?= isset($reg)? $reg:'' ?>">
                                <i class="fa fa-user"></i>
                            </span>
                            <?php
                                if(isset($input_errores["reg"])){
                                 echo  '<span class="inputsms">'.  $input_errores['reg']  . '</span>';
                                }
                                ?>



                        </div>
                        
                        <div class="form-group mt-md">
                            <span class="input-with-icon">
                                <input type="text" class="form-control" name="phone" placeholder="01........" pattern="01[3/1/9/6/8/7][0-9]{8}" value="<?= isset($phone)? $phone:'' ?>">
                                <i class="fa fa-phone"></i>
                            </span>
                            <?php
                                if(isset($input_errores["phone"])){
                                 echo  '<span class="inputsms">'.  $input_errores['phone']  . '</span>';
                                }
                                ?>
                        </div>
                                    
                          
                             

                                   
                            
                        <div class="form-group mt-md">
                            <span class="input-with-icon">
                                <input type="email" class="form-control" name="email" placeholder="Email" value="<?= isset($email)? $email:'' ?>">
                                <i class="fa fa-envelope"></i>
                            </span>
                         <?php
                                

                                if(isset($input_errores["email"])){
                                 echo  '<span class="inputsms">'.  $input_errores['email']  . '</span>';
                                }
                                ?>


                        </div>
                        <div class="form-group">
                            <span class="input-with-icon">
                              
                                
                               
                                <input type="text" class="form-control" name="username" placeholder="username" value="<?= isset($username)? $username:'' ?>">
                                <i class="fa fa-user"></i>
                                      </span>
                               
                            
                            <?php
                                if(isset($input_errores["username"])){
                                 echo  '<span class="inputsms">'.  $input_errores['username']  . '</span>';
                                }
                                ?>
                        </div>
                        <div class="form-group">
                            <span class="input-with-icon">
                                <input type="password" class="form-control" name="password" placeholder="Password" >
                                <i class="fa fa-key"></i>
                            </span>
                            <?php
                                if(isset($input_errores["password"])){
                                 echo  '<span class="inputsms">'.  $input_errores['password']  . '</span>';
                                }
                                ?>



                        </div>
                        
                        </div>
                        <div class="form-group">
                            <input type="submit" name="student-register" value="register" class="btn btn-primary btn-block">
                        </div>
                        <div class="form-group text-center">
                            Have an account?, <a href="login.php">Sign In</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
    </div>
</div>
<!--BASIC scripts-->
<!-- ========================================================= -->
<script src="../assets/vendor/jquery/jquery-1.12.3.min.js"></script>
<script src="../assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="../assets/vendor/nano-scroller/nano-scroller.js"></script>
<!--TEMPLATE scripts-->
<!-- ========================================================= -->
<script src="../assets/javascripts/template-script.min.js"></script>
<script src="../assets/javascripts/template-init.min.js"></script>
<!-- SECTION script and examples-->
<!-- ========================================================= -->
</body>


</html>
